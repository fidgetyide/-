from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from prompts import SUMMARY_PROMPT, TASK_PROMPT, REPORT_PROMPT
from dotenv import load_dotenv

load_dotenv()

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.3
)


class SummaryAgent:

    def run(self, content):
        prompt = PromptTemplate.from_template(SUMMARY_PROMPT)
        chain = prompt | llm

        result = chain.invoke({
            "content": content
        })

        return result.content


class TaskAgent:

    def run(self, content):
        prompt = PromptTemplate.from_template(TASK_PROMPT)
        chain = prompt | llm

        result = chain.invoke({
            "content": content
        })

        return result.content


class ReportAgent:

    def run(self, content):
        prompt = PromptTemplate.from_template(REPORT_PROMPT)
        chain = prompt | llm

        result = chain.invoke({
            "content": content
        })

        return result.content
