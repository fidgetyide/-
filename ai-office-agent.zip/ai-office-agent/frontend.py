import streamlit as st
import requests

st.set_page_config(page_title="AI Office Agent")

st.title("AI 办公效率 Agent")

content = st.text_area(
    "请输入会议内容",
    height=300
)

if st.button("开始生成"):

    response = requests.post(
        "http://127.0.0.1:8000/process",
        json={
            "content": content
        }
    )

    data = response.json()

    st.subheader("会议纪要")
    st.write(data["summary"])

    st.subheader("待办事项")
    st.write(data["tasks"])

    st.subheader("日报内容")
    st.write(data["report"])
