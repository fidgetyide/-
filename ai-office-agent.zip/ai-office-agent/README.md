# AI Office Agent

基于 Multi-Agent Workflow 的 AI 办公自动化系统。

## 功能
- 自动生成会议纪要
- 自动提取待办事项
- 自动生成日报/周报
- FastAPI + Streamlit 前后端

## 安装

```bash
pip install -r requirements.txt
```

## 配置 API KEY

复制 `.env.example` 为 `.env`

```env
OPENAI_API_KEY=你的KEY
```

## 启动后端

```bash
uvicorn app:app --reload
```

## 启动前端

```bash
streamlit run frontend.py
```
