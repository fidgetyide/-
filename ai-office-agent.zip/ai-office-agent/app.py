from fastapi import FastAPI
from pydantic import BaseModel

from agents import SummaryAgent
from agents import TaskAgent
from agents import ReportAgent

from database import SessionLocal
from database import MeetingRecord

app = FastAPI()

summary_agent = SummaryAgent()
task_agent = TaskAgent()
report_agent = ReportAgent()


class MeetingInput(BaseModel):
    content: str


@app.get("/")
def home():
    return {
        "message": "AI Office Agent Running"
    }


@app.post("/process")
def process_meeting(data: MeetingInput):

    content = data.content

    summary = summary_agent.run(content)

    tasks = task_agent.run(content)

    report = report_agent.run(tasks)

    db = SessionLocal()

    record = MeetingRecord(
        raw_text=content,
        summary=summary,
        tasks=tasks
    )

    db.add(record)
    db.commit()

    return {
        "summary": summary,
        "tasks": tasks,
        "report": report
    }
