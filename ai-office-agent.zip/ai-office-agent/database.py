from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import Column, Integer, Text

DATABASE_URL = "sqlite:///office_agent.db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()


class MeetingRecord(Base):
    __tablename__ = "meeting_records"

    id = Column(Integer, primary_key=True, index=True)
    raw_text = Column(Text)
    summary = Column(Text)
    tasks = Column(Text)


Base.metadata.create_all(bind=engine)
